﻿<?php
echo header("Access-Control-Allow-Origin:*");
require_once "jssdk.php";
$url=$_GET["url"];
$jssdk = new JSSDK("wxbb8dc5a9ecb3447d", "ecf77433bfa553f24c2577fe2cbae39a",$url);
$signPackage = $jssdk->GetSignPackage();
echo json_encode($signPackage);
?>