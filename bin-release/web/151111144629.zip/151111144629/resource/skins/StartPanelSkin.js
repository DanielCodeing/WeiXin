var StartPanelSkin=(function (_super) {
	__extends(StartPanelSkin, _super);
	function StartPanelSkin() {
		_super.call(this);
		
		this.height = 756;
		this.width = 480;
		this.elementsContent = [this.logo_i(),this._Image1_i(),this.btnGui_i(),this.carq_i(),this.btnGo_i(),this.carh_i(),this.title_i(),this.yanjing_i()];
	}
	var _proto = StartPanelSkin.prototype;

	_proto.logo_i = function () {
		var t = new eui.Image();
		this.logo = t;
		t.horizontalCenter = 0;
		t.source = "logo";
		t.y = 215;
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.source = "startbg";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.btnGui_i = function () {
		var t = new eui.Image();
		this.btnGui = t;
		t.source = "btnGui";
		t.x = 181;
		t.y = 698;
		return t;
	};
	_proto.carq_i = function () {
		var t = new eui.Image();
		this.carq = t;
		t.source = "carq";
		t.x = 21;
		t.y = 444;
		return t;
	};
	_proto.btnGo_i = function () {
		var t = new eui.Image();
		this.btnGo = t;
		t.horizontalCenter = 0.5;
		t.source = "btnGo";
		t.y = 613;
		return t;
	};
	_proto.carh_i = function () {
		var t = new eui.Image();
		this.carh = t;
		t.source = "carh";
		t.x = 362;
		t.y = 409;
		return t;
	};
	_proto.title_i = function () {
		var t = new eui.Image();
		this.title = t;
		t.horizontalCenter = 0;
		t.source = "title";
		t.y = 73;
		return t;
	};
	_proto.yanjing_i = function () {
		var t = new eui.Image();
		this.yanjing = t;
		t.source = "yanjing";
		t.x = 159;
		t.y = 161;
		return t;
	};
	Object.defineProperty(_proto, "skinParts", {
		get: function () {
			return ["logo","btnGui","carq","btnGo","carh","title","yanjing"];
		},
		enumerable: true,
		configurable: true
	});
	return StartPanelSkin;
})(eui.Skin);