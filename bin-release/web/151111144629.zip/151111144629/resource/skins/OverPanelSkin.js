var StartPanelSkin=(function (_super) {
	__extends(StartPanelSkin, _super);
	function StartPanelSkin() {
		_super.call(this);
		
		this.height = 756;
		this.width = 480;
		this.elementsContent = [this.background_i(),this.btnLing_i(),this.btnShare_i(),this.title_i(),this.btnClose_i(),this.txtScore_i(),this.share_i()];
	}
	var _proto = StartPanelSkin.prototype;

	_proto.background_i = function () {
		var t = new eui.Image();
		this.background = t;
		t.source = "overbg";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.btnLing_i = function () {
		var t = new eui.Image();
		this.btnLing = t;
		t.source = "btnLing";
		t.x = 87;
		t.y = 440;
		return t;
	};
	_proto.btnShare_i = function () {
		var t = new eui.Image();
		this.btnShare = t;
		t.source = "btnShare";
		t.x = 264;
		t.y = 440;
		return t;
	};
	_proto.title_i = function () {
		var t = new eui.Image();
		this.title = t;
		t.horizontalCenter = 0;
		t.source = "num1";
		t.y = 141;
		return t;
	};
	_proto.btnClose_i = function () {
		var t = new eui.Image();
		this.btnClose = t;
		t.source = "btnClose";
		t.x = 406;
		t.y = 200;
		return t;
	};
	_proto.txtScore_i = function () {
		var t = new eui.Label();
		this.txtScore = t;
		t.bold = true;
		t.fontFamily = "微软雅黑";
		t.size = 24;
		t.text = "100";
		t.textAlign = "center";
		t.textColor = 0xF50808;
		t.width = 77;
		t.x = 220;
		t.y = 285;
		return t;
	};
	_proto.share_i = function () {
		var t = new eui.Image();
		this.share = t;
		t.source = "share";
		t.visible = false;
		t.x = 0;
		t.y = 0;
		return t;
	};
	Object.defineProperty(_proto, "skinParts", {
		get: function () {
			return ["background","btnLing","btnShare","title","btnClose","txtScore","share"];
		},
		enumerable: true,
		configurable: true
	});
	return StartPanelSkin;
})(eui.Skin);