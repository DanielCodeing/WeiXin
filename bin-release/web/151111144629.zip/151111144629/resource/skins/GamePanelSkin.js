var StartPanelSkin=(function (_super) {
	__extends(StartPanelSkin, _super);
	function StartPanelSkin() {
		_super.call(this);
		
		this.height = 756;
		this.width = 480;
		this.elementsContent = [this.background_i(),this.btnMusicOn_i(),this.btnMusicOff_i(),this.tips_i()];
	}
	var _proto = StartPanelSkin.prototype;

	_proto.background_i = function () {
		var t = new eui.Image();
		this.background = t;
		t.source = "game_background_png";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.btnMusicOn_i = function () {
		var t = new eui.Image();
		this.btnMusicOn = t;
		t.source = "btnMusicOn";
		t.x = 426;
		t.y = 10;
		return t;
	};
	_proto.btnMusicOff_i = function () {
		var t = new eui.Image();
		this.btnMusicOff = t;
		t.source = "btnMusicOff";
		t.x = 426;
		t.y = 9;
		return t;
	};
	_proto.tips_i = function () {
		var t = new eui.Image();
		this.tips = t;
		t.source = "tips";
		t.x = 0;
		t.y = 0;
		return t;
	};
	Object.defineProperty(_proto, "skinParts", {
		get: function () {
			return ["background","btnMusicOn","btnMusicOff","tips"];
		},
		enumerable: true,
		configurable: true
	});
	return StartPanelSkin;
})(eui.Skin);