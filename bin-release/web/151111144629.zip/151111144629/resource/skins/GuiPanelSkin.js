var GuiPanelSkin=(function (_super) {
	__extends(GuiPanelSkin, _super);
	function GuiPanelSkin() {
		_super.call(this);
		
		this.height = 756;
		this.width = 480;
		this.elementsContent = [this._Image1_i(),this.btnClose_i()];
	}
	var _proto = GuiPanelSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.source = "guize";
		t.x = 0;
		t.y = 0;
		return t;
	};
	_proto.btnClose_i = function () {
		var t = new eui.Image();
		this.btnClose = t;
		t.source = "btnClose";
		t.x = 404;
		t.y = 195;
		return t;
	};
	Object.defineProperty(_proto, "skinParts", {
		get: function () {
			return ["btnClose"];
		},
		enumerable: true,
		configurable: true
	});
	return GuiPanelSkin;
})(eui.Skin);